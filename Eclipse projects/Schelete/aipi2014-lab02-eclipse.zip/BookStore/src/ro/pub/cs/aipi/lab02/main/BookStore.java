package ro.pub.cs.aipi.lab02.main;

import javax.sql.rowset.FilteredRowSet;
import javax.sql.rowset.JoinRowSet;

public class BookStore {

	public int exercise2(String tableName) {
		int tableNumberOfRows				= -1;
		// TO DO: exercise 2
		return tableNumberOfRows;
	}

	public void exercise3() {
		// TO DO: exercise 3
	}

	public int exercise4() {
		int result = -1;
		// TO DO: exercise 4
		return result;
	}

	public int exercise5() {
		int result = -1;
		// TO DO: exercise 5
		return result;
	}

	public int exercise6() {
		int result = -1;
		// TO DO: exercise 6
		return result;
	}

	public void exercise7() {
		// TO DO: exercise 7
	}

	public void exercise8() {
		// TO DO: exercise 8   
	}

	public void exercise9() {
		// TO DO: exercise 9
	}

	public JoinRowSet exercise10() {
		JoinRowSet joinRowSet = null;
		// TO DO: exercise 10
		return joinRowSet;
	}

	public FilteredRowSet exercise11() {
		FilteredRowSet filteredRowSet = null;
		// TO DO: exercise 11
		return filteredRowSet;
	}
}
