package ro.pub.cs.aipi.lab03.model;

import java.util.ArrayList;

public abstract class Model {

    public abstract ArrayList<String> getValues();
}
